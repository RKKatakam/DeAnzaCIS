public class HashTable {
    private Krone[] table;
    private int numberOfDataItems;
    private int numberOfCollisions;
    private int size;
    private double loadFactor;

    public HashTable(int size) {
        this.size = size;
        table = new Krone[size];
        numberOfDataItems = 0;
        numberOfCollisions = 0;
    }


    public void insert(Krone k) {
        //do check if the table is full
        if (numberOfDataItems == table.length) {
            System.out.println("Table is full");
            return;
        }

        int index = hash(k);
        if (table[index] != null) {
            numberOfCollisions++;
            int i = 1;
            while (table[index] != null) {
                index = (index + (i * i)) % size;
                i++;
            }
        }
        table[index] = k;
        numberOfDataItems++;
        loadFactor = (double) numberOfDataItems / size;
    }

    public int search(Krone k) {
        int index = hash(k);
        if (table[index] != null) {
            int i = 1;
            while (table[index] != null) {
                if (table[index].isEquals(k)) {
                    return index;
                }
                index = (index + (i * i)) % size;
                i++;
            }
        }
        return -1;
    }

    public int hash(Krone k) {
        int m = 2;
        int n = 3;
        int w = k.getWholePart();
        int f = k.getFractionalPart();
        return ((m * w) + (n * f)) % size;
    }

    public Krone[] getTable() {
        return table;
    }

    public int getNumberOfDataItems() {
        return numberOfDataItems;
    }

    public int getNumberOfCollisions() {
        return numberOfCollisions;
    }

    public int getSize() {
        return size;
    }


    public double getLoadFactor() {
        return loadFactor;
    }
}
